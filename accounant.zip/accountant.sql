-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 06 2025 г., 14:53
-- Версия сервера: 5.5.53
-- Версия PHP: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `accountant`
--

-- --------------------------------------------------------

--
-- Структура таблицы `executor`
--

CREATE TABLE `executor` (
  `idexecutor` int(11) NOT NULL,
  `executor` char(80) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(80) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `executor`
--

INSERT INTO `executor` (`idexecutor`, `executor`, `phone`) VALUES
(1, 'Милованов ВА', '342233'),
(2, 'Макаров КА', '675533'),
(3, 'Петрова ОЛ', '512442'),
(4, 'Филимонов ВВ', '646332'),
(5, 'Мелехин ВА', '533344');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE `news` (
  `idnews` int(11) NOT NULL,
  `news` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `file` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `idusersystem` int(11) NOT NULL,
  `datenews` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`idnews`, `news`, `info`, `file`, `idusersystem`, `datenews`) VALUES
(1, 'Новые условия по услугам!', 'Скоро будут введены новые условия по услугам!', 'news4.jpg', 1, '2024-04-28 15:22:00'),
(2, 'Работник месяца!', 'Работник месяца - Иванов ВА', 'news6.jpg', 1, '2026-05-01 17:20:00'),
(3, 'Теперь нам можно позвонить!', 'Номер для любых вопросов: 332288', 'news7.jpg', 1, '2026-05-17 13:00:00'),
(4, 'Теперь мы готовы к новым отношениям!', 'Изменения условий соглашения успешно выполнены!', 'news5.jpg', 1, '2024-04-24 12:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `orderclient`
--

CREATE TABLE `orderclient` (
  `idorderclient` int(11) NOT NULL,
  `dateorder` date DEFAULT NULL,
  `status` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `term` date DEFAULT NULL,
  `idclient` int(11) NOT NULL,
  `idservice` int(11) DEFAULT NULL,
  `idexecutor` int(11) DEFAULT NULL,
  `problem` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `file` varchar(80) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `orderclient`
--

INSERT INTO `orderclient` (`idorderclient`, `dateorder`, `status`, `term`, `idclient`, `idservice`, `idexecutor`, `problem`, `file`) VALUES
(1, '2026-05-08', 'Готово', '2026-05-11', 3, 2, 3, 'Проблема с рынком', NULL),
(2, '2026-05-15', 'В процессе', '2026-05-25', 4, 5, 2, 'Нужен анализ рынка', NULL),
(4, '2026-05-01', 'Открыто', '2026-05-01', 3, NULL, 3, 'Нужен рекламный клип', 'cc290925.png'),
(10, '2026-05-01', 'Открыто', '2026-05-01', 3, NULL, 2, 'Нужна реклама', 'fun_killer_king.c6cc2925.png'),
(11, '2026-05-01', 'В процессе', '2026-05-09', 4, 6, NULL, 'Нужен договор', 'cc2925.png');

-- --------------------------------------------------------

--
-- Структура таблицы `service`
--

CREATE TABLE `service` (
  `idservice` int(11) NOT NULL,
  `service` varchar(120) COLLATE utf8_bin DEFAULT NULL,
  `code` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `service`
--

INSERT INTO `service` (`idservice`, `service`, `code`, `cost`) VALUES
(1, 'Настройка таргетированной рекламы для приёмной кампании', '73.11.10', 45000),
(2, 'SMM-сопровождение страниц факультета или кафедры', '73.11.10', 15000),
(3, 'Создание информационного контента для сайта и соцсетей вуза', '73.11.13', 25000),
(4, 'Разработка стратегии продвижения новой образовательной программы', '73.11.19', 30000),
(5, 'Организация email-рассылок для абитуриентов, студентов и выпускников', '73.11.13', 10000),
(6, 'SEO-оптимизация страниц структурных подразделений на сайте университета', '73.11.19', 20000),
(7, 'Дизайн полиграфической и сувенирной продукции (баннеры, буклеты, roll-up)', '73.11.13', 35000),
(8, 'Аналитика и отчётность по эффективности маркетинговых активностей', '73.11.19', 15000);

-- --------------------------------------------------------

--
-- Структура таблицы `usersystem`
--

CREATE TABLE `usersystem` (
  `usersystem` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `idusersystem` int(11) NOT NULL,
  `login` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `parol` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `permission` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `mail` varchar(40) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `usersystem`
--

INSERT INTO `usersystem` (`usersystem`, `phone`, `idusersystem`, `login`, `parol`, `permission`, `mail`) VALUES
('Антонов ВА', '23342', 1, 'admin', 'master', 'Администратор', 'wer@ya.ru'),
('Макаров ВА', '342211', 2, 'asdf', 'qwer', 'Менеджер', NULL),
('Михайлов ВА (кафедра ИВС)', '23342', 3, 'asdf', 'zxcv', 'Заказчик', NULL),
('Аристократов АВ (кафедра Мировой экономики)', '122112', 4, 'qwerty', 'asdfgh', 'Заказчик', '356@sf.re');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `executor`
--
ALTER TABLE `executor`
  ADD PRIMARY KEY (`idexecutor`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`idnews`),
  ADD KEY `idusersystem` (`idusersystem`);

--
-- Индексы таблицы `orderclient`
--
ALTER TABLE `orderclient`
  ADD PRIMARY KEY (`idorderclient`),
  ADD KEY `idclient` (`idclient`),
  ADD KEY `idservice` (`idservice`),
  ADD KEY `idexecutor` (`idexecutor`);

--
-- Индексы таблицы `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`idservice`);

--
-- Индексы таблицы `usersystem`
--
ALTER TABLE `usersystem`
  ADD PRIMARY KEY (`idusersystem`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `executor`
--
ALTER TABLE `executor`
  MODIFY `idexecutor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `idnews` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `orderclient`
--
ALTER TABLE `orderclient`
  MODIFY `idorderclient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `service`
--
ALTER TABLE `service`
  MODIFY `idservice` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `usersystem`
--
ALTER TABLE `usersystem`
  MODIFY `idusersystem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `news`
--
ALTER TABLE `news`
  ADD CONSTRAINT `news_ibfk_1` FOREIGN KEY (`idusersystem`) REFERENCES `usersystem` (`idusersystem`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `orderclient`
--
ALTER TABLE `orderclient`
  ADD CONSTRAINT `orderclient_ibfk_1` FOREIGN KEY (`idclient`) REFERENCES `usersystem` (`idusersystem`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderclient_ibfk_2` FOREIGN KEY (`idservice`) REFERENCES `service` (`idservice`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderclient_ibfk_3` FOREIGN KEY (`idexecutor`) REFERENCES `executor` (`idexecutor`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
