<?
require "option.php";//файл с параметрами подключения к БД
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title><? echo $permission;?></title>
	<meta charset="utf-8" content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
</head>
<body>
<?
if ($permission!="Менеджер")
{
?>
<script language="javascript">
alert("Требуется авторизация!");
</script>
<?
exit;
}

$Arr=$_REQUEST["arrorderclient"];
//phpinfo(32);
$r=mysqli_query($dbcnx,"select * from usersystem, orderclient where orderclient.idclient=usersystem.idusersystem and orderclient.idorderclient=$Arr[0]");

$f=mysqli_fetch_array($r);//считывание текующей записи
	  
?>
     
     
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				<a href="#" class="logo">
					Менеджер
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
			</div>
			<nav class="navbar navbar-header navbar-expand-lg">
				<div class="container-fluid">
					

					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">

						
						<li class="nav-item dropdown">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false"> <span ><? echo $usersystem;?></span></span> </a>
							<ul class="dropdown-menu dropdown-user">
								<li>
									<div class="user-box">
										
										<div class="u-text">
											<h4><? echo $usersystem;?></h4>
											<p class="text-muted"><? echo $permission;?></p>
											
                                        </div>
									</div>
								</li>
									<div class="dropdown-divider"></div>
									
									<a class="dropdown-item" href="index.php?step=2"><i class="fa fa-power-off"></i> Выход</a>
								</ul>
								<!-- /.dropdown-user -->
							</li>
						</ul>
					</div>
				</nav>
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
					<div class="user">


					</div>
					<ul class="nav">
						<li class="nav-item">
							<a href="index.php">
								<i class="la la-home"></i>
								<p>Главная</p>
						
							</a>
						</li>
						<li class="nav-item">
							<a href="reqmng.php">
								<i class="la la-dashboard"></i>
								<b><p>Заявки</p></b>
								                                  
							</a>
						</li>
                        <li class="nav-item">
							<a href="executor.php">
								<i class="la la-weixin"></i>
								<p>Исполнительы</p>

							</a>
						</li>
                        <li class="nav-item">
							<a href="service.php">
								<i class="la la-star-o"></i>
								<p>Услуги</p>

							</a>
						</li> 					                       					                         <li class="nav-item">
							<a href="news.php">
								<i class="la la-paper-plane"></i>
								<p>Новости</p>

							</a>
						</li>  	
					</ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">

                    
                   
				<div class="card">
				
<form name="form2" method="post"  >

								
									<div class="card-header">
										<div class="card-title">Информация о заказчике заявки №<? echo $f["idorderclient"];?></div>

 
                                         
									</div>
                                    
									<div class="card-body">
				  <table border="0">
	                   
                    <tr>
                      <td width="25%"><font color="#000000" >   ФИО: </font> </td>
                      <td><input class="form-control input-full" size="30" readonly name="usersystem"   type="text"  value="<? echo $f['usersystem'] ?>"  ></td>
                    </tr>  	          
                    <tr>
                      <td width="25%"><font color="#000000" >   Телефон: </font> </td>
                      <td><input class="form-control input-full" size="30" readonly name="phone"   type="text"  value="<? echo $f['phone'] ?>"  ></td>
                    </tr>  	                                                                                     
                    <tr>
                      <td width="25%"><font color="#000000" >   Почта: </font> </td>
                      <td><input class="form-control input-full" size="30" readonly name="mail"   type="text"  value="<? echo $f['mail'] ?>"  ></td>
                    </tr>  	
	                    
                                      
 
                      
                  </table>
<br>
				<input class="btn btn-success" type="button"  name="button"  onClick="javascript:history.back();"  value="Назад">

		</form>				
           					</div>
                            

					</div>
				</div>     
                <div>

                                               
                </div>
				<footer class="footer">
					<div class="container-fluid"  >
						<nav class="pull-left">
							<ul class="nav">

							</ul>
						</nav>
						<div class="copyright ml-auto">
						Все права защищены &copy; <? echo DATE("Y");?>
						</div>				
					</div>
				</footer>
			</div>
		</div>
	</div>
</div>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script>
	$('#displayNotif').on('click', function(){
		var placementFrom = $('#notify_placement_from option:selected').val();
		var placementAlign = $('#notify_placement_align option:selected').val();
		var state = $('#notify_state option:selected').val();
		var style = $('#notify_style option:selected').val();
		var content = {};

		content.message = 'Turning standard Bootstrap alerts into "notify" like notifications';
		content.title = 'Bootstrap notify';
		if (style == "withicon") {
			content.icon = 'la la-bell';
		} else {
			content.icon = 'none';
		}
		content.url = 'index.html';
		content.target = '_blank';

		$.notify(content,{
			type: state,
			placement: {
				from: placementFrom,
				align: placementAlign
			},
			time: 1000,
		});
	});
</script>
</html>