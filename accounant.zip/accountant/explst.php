<?
require "option.php";//файл с параметрами подключения к БД
date_default_timezone_set("Europe/Moscow");
$date=date("Y")."-".date("m")."-".date("d");   

	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=Заявки от '.$date.'.xls');
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0'); 
    header('Cache-Control: must-revalidate');
    header('Pragma: public');   


 	?>				   
		
<html >
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><? echo $permission;?></title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>


<br>

   <?


		$filter=$_GET["filter"];//считывание параметра фильтра
		$sort=$_GET["sort"];//считывание параметра фильтра		



if ($filter==0)/*есть ли фильтрация данных*/
{
date_default_timezone_set("Europe/Moscow");
$date1=(date("Y")-1)."-".date("m")."-".date("d");    
$date2=(date("Y")+1)."-".date("m")."-".date("d");    
}

$s="SELECT orderclient.*, usersystem, executor, service, cost FROM usersystem, orderclient LEFT JOIN executor ON executor.idexecutor=orderclient.idexecutor LEFT JOIN service  ON service.idservice=orderclient.idservice WHERE orderclient.idclient=usersystem.idusersystem ";
	
if ($filter==1)/*есть ли фильтрация данных*/
{
$date1=$_POST['date1'];    
$date2=$_POST['date2'];    
 
$fieldfind = $_POST['findname'];//первое поле
$value1 = $_POST['FilterValue1'];//значение первого поля

if ($value1!="Все")
$s=$s."and UPPER($fieldfind) LIKE UPPER('%$value1"."%')  ";
else
$s=$s."and $fieldfind=$fieldfind ";

$s=$s." and dateorder>='$date1' and dateorder<='$date2' ";
}


if ($sort==1)/*есть ли сортировка данных*/
{
$fieldsort = $_POST['sortname'];//первое поле
$s=$s." order by $fieldsort";
}
else
$s=$s." order by dateorder";

$r=mysqli_query($dbcnx,$s);

	 ?>
     
<font  size="+1" >   Ведомость заявок от <? echo $date;?>  </font> 

 
 <table border=1>
											<thead>
												<tr>
                                  
		<th scope="col">Дата</th>
		<th scope="col">Номер</th>
		<th scope="col">Заказчик</th>
		<th scope="col">Проблема</th>		
		<th scope="col">Услуга</th> 	
		<th scope="col">Исполнитель</th>	              
		<th scope="col">Сроки</th>	                
		<th scope="col">Статус</th>
		<th scope="col">Стоимость</th>              
            

                                       			        
                                                    </tr>
											</thead>
											<tbody>
        
        
      <?
		 
		

			for ($i=0;$i<mysqli_num_rows($r);$i++)//вывод данных в цикле по количеству записей
			  {
				$f=mysqli_fetch_array($r);//считывание текующей записи				
				echo "<tr>";

?>			 
		
				<?
				echo "
				<td> ".$f['dateorder']."</td>
				<td> ".$f['idorderclient']."</td>
				<td> ".$f['usersystem']."</td>											
				<td> ".$f['problem']."</td>
				<td> ".$f['service']."</td>";			
				if 	($f['executor']==null)																	
					echo "<td>Не назначен</td>";
				else
					echo "<td> ".$f['executor']."</td>";
		echo "
				<td> ".$f['term']."</td>					
				<td> ".$f['status']."</td>";
				if 	($f['cost']==null)																	
					echo "<td>Не рассчитана</td>";
				else
					echo "<td> ".$f['cost']."</td>";				

											
				echo "</tr>";
			  }		 
		?>
      
</tbody>
										</table>

       

</body>
</html>
