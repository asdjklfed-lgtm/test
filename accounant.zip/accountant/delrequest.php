<?
require "option.php";
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<?
$Arr=$_POST['arrorderclient'];
$id=$Arr[0];
mysqli_query($dbcnx,"DELETE FROM orderclient  WHERE idorderclient=$id");


if ($permission=="Заказчик")
{

?>
 <script language="javascript">
 location.href='reqclt.php';
 </script>
<?
}
if ($permission=="Менеджер")
{
?>
 <script language="javascript">
 location.href='reqmng.php';
 </script>
<?
}

?>