<?
require "option.php";//файл с параметрами подключения к БД

if ($permission!="Заказчик")
{
?>
<meta charset="utf-8">
<script language="javascript">
alert("Требуется авторизация!");
</script>
<?
exit;
}

$step=$_REQUEST["step"];

if ($step==1)
setcookie ('file', '');


if ($step==3)
{
setcookie ( 'file', basename($_FILES["file"]["name"]));	

$uploaddir = 'upload/';
$uploadfile = $uploaddir . basename($_FILES["file"]["name"]);
$uploadfile =iconv('utf-8', 'windows-1251', $uploadfile );			


if ( ($_FILES["file"]['size'] > 1993216) || ($_FILES["file"]['size'] <= 0) )
{
?>
<meta charset="utf-8">
	 <script language="javascript">
	 alert ('Слишком большой файл! <? echo $_FILES["file"]['size'];?>, <? echo basename($_FILES["file"]['name']);?>');
	 history.back();
	 </script>
<?
}
else
move_uploaded_file($_FILES["file"]['tmp_name'], $uploadfile);
/*
if (move_uploaded_file($_FILES["file"]['tmp_name'], $uploadfile)) 
    echo "Файл корректен и был успешно загружен.\n";
 else 
    echo "Возможная атака с помощью файловой загрузки!\n";
*/    
?>
<meta charset="utf-8">
	 <script language="javascript">
	 history.back();
	 </script>
<?
}

date_default_timezone_set("Europe/Moscow");
$date=date("Y")."-".date("m")."-".date("d");   



if ($step==2)
{
$upd=$_REQUEST["upd"];

$status =  "Открыто";
$term =  $_POST["term"];
$dateorder =  $_POST["dateorder"];
$problem =  $_POST["problem"];
	
if ($file==NULL)
$file="";	
	
if ($upd==1)
  {  
     $id=$_REQUEST["id"];
     	 $s="UPDATE orderclient set ";
	 if ($file!="")
  		 $s=$s."file='$file',";
	 $s=$s."dateorder='$dateorder', status='$status' ,term='$term' , problem='$problem' WHERE idorderclient=$id";
	 mysqli_query($dbcnx,$s);
	 


  }  else
  {//формирование SQL-запроса на добавление данных
	 mysqli_query($dbcnx, "INSERT INTO orderclient (file, status, idclient, dateorder, term, problem) VALUES ('$file', '$status', $idusersystem, '$dateorder', '$term', '$problem')");

  }	
  
  ?>
	 <script language="javascript">
	 location.href='reqclt.php?filter=0';
	 </script>
	 <?
}

	 $upd=$_REQUEST["upd"];

	 if ($upd==1)
		{
	 $Arr=$_REQUEST["arrorderclient"];
	 $idorderclient=$Arr[0];
	 $r=mysqli_query($dbcnx, "select * from orderclient where idorderclient=$idorderclient");
	 $f=mysqli_fetch_array($r);
	 }
     ?>


<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title><? echo $permission;?></title>
	<meta charset="utf-8" content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
</head>
<body>     
     
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				<a href="#" class="logo">
					Заказчик
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
			</div>
			<nav class="navbar navbar-header navbar-expand-lg">
				<div class="container-fluid">
					

					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">

						
						<li class="nav-item dropdown">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false"> <span ><? echo $usersystem;?></span></span> </a>
							<ul class="dropdown-menu dropdown-user">
								<li>
									<div class="user-box">
										
										<div class="u-text">
											<h4><? echo $usersystem;?></h4>
											<p class="text-muted"><? echo $permission;?></p>
											
                                        </div>
									</div>
								</li>
									<div class="dropdown-divider"></div>
									
									<a class="dropdown-item" href="index.php?step=2"><i class="fa fa-power-off"></i> Выход</a>
								</ul>
								<!-- /.dropdown-user -->
							</li>
						</ul>
					</div>
				</nav>
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
					<div class="user">


					</div>
					<ul class="nav">
						<li class="nav-item">
							<a href="index.php">
								<i class="la la-home"></i>
								<p>Главная</p>
						
							</a>
						</li>
						<li class="nav-item">
							<a href="reqclt.php">
								<i class="la la-dashboard"></i>
								<p>Заявки</p>
                                   
							</a>
						</li>
					                       						
					</ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">

                    
                   
				<div class="card">
				
				
				
				
<form name="form2"  method="post"  enctype="multipart/form-data" >

								
									<div class="card-header">
	 								<? 
									if ($upd==0){ 
									?>
										<div class="card-title">Добавление заявки</div>
                                    <?
									}
									else
									{
									?>
										<div class="card-title">Редактирование заявки №<? echo $f["idorderclient"];?></div>
									<?
                                    					}
									?>  
                                         
									</div>
                                    
									<div class="card-body">
				  <table border="0">
                    <tr>
                      <td><font   color="#000000" > Файл: </font></td>
                      <td> 

						 <input name="file" type="file" size="19" />  
                         <input type="button"  name="button"  value="Загрузить" 
                         onClick="this.form.action='updreqclt.php?step=3'; this.form.submit();">
                      </td>
                    </tr> 

                    
                    <tr>
                      <td><font   color="#000000" >   Проблема: </font> </td>
                      <td><input class="form-control input-full"    name="problem" size="55"   type="text"  value="<? if ($upd==1) echo htmlentities($f['problem']); else echo(""); ?>"  ></td>
                    </tr>                        
 	                                                           
                    <tr>
                      <td><font color="#000000" >  Дата: </font> </td>
                      <td><input  class="form-control input-full" type="date"  name="dateorder"  value="<? if ($upd==1) echo $f['dateorder']; else echo("$date"); ?>"   type="text" ></td>
                    </tr>    
                    <tr>
                      <td><font color="#000000" >  Сроки: </font> </td>
                      <td><input  class="form-control input-full" type="date"  name="term"  value="<? if ($upd==1) echo $f['term']; else echo("$date"); ?>"   type="text" ></td>
                    </tr>                                                                                                                                         


  
                  
 
                      
                  </table>
<br>
				<input  class="btn btn-success" type="button"  name="button"   onclick="this.form.action='updreqclt.php?step=2&upd=<? echo"$upd";?>&id=<? echo"$Arr[0]";?>'; this.form.submit();"   value="Сохранить" width="500">
				<input   class="btn btn-danger" type="button"  name="button"  onClick="javascript:history.back();"  value="Отмена">
                                    
                                    
                                    	
									</div>

      </form>	            
           					</div>
                            

					</div>
				</div>     
                <div>

                                               
                </div>
				<footer class="footer">
					<div class="container-fluid"  >
						<nav class="pull-left">
							<ul class="nav">

							</ul>
						</nav>
						<div class="copyright ml-auto">
						Все права защищены &copy; <? echo DATE("Y");?>
						</div>				
					</div>
				</footer>
			</div>
		</div>
	</div>
</div>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script>
	$('#displayNotif').on('click', function(){
		var placementFrom = $('#notify_placement_from option:selected').val();
		var placementAlign = $('#notify_placement_align option:selected').val();
		var state = $('#notify_state option:selected').val();
		var style = $('#notify_style option:selected').val();
		var content = {};

		content.message = 'Turning standard Bootstrap alerts into "notify" like notifications';
		content.title = 'Bootstrap notify';
		if (style == "withicon") {
			content.icon = 'la la-bell';
		} else {
			content.icon = 'none';
		}
		content.url = 'index.html';
		content.target = '_blank';

		$.notify(content,{
			type: state,
			placement: {
				from: placementFrom,
				align: placementAlign
			},
			time: 1000,
		});
	});
</script>
</html>