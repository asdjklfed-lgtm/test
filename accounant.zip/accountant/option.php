<?
//считывание cookie
$permission=$_COOKIE["permission"];  
$user=$_COOKIE["fio"];  
$idworker=$_COOKIE["idworker"];  
$mail=$_COOKIE["mail"];  
$file=$_COOKIE["file"];
$idclient=$_COOKIE["idclient"];  
$idrequest=$_COOKIE["idrequest"]; 

$now=date("Y")."-".date("m")."-".date("d");    
	
//константы
$yearstring = 4;
$requiredstring = 6;
$shortstring = 100;
$longstring = 200;

//подключение к БД
$dblocation = "localhost";
$dbname = "accountant";
$dbuser = "root";
$dbpasswd = "";
$dbcnx = mysqli_connect($dblocation,$dbuser,$dbpasswd,$dbname);

    if(!$dbcnx)
    {
    ?>
    <meta charset="utf-8">
    <?
      echo 'Невозможно соединиться с БД';
      exit;
	}

?>
