<?
require "option.php";//файл с параметрами подключения к БД

$Arr=$_POST['arrorderclient'];
$idorderclient=$Arr[0];

$s="SELECT orderclient.*, usersystem, usersystem.phone as usersystemphone, mail, executor, executor.phone as executorphone, service, cost FROM usersystem, orderclient LEFT JOIN executor ON executor.idexecutor=orderclient.idexecutor LEFT JOIN service ON service.idservice=orderclient.idservice WHERE orderclient.idclient=usersystem.idusersystem and idorderclient=$idorderclient";
$r=mysqli_query($dbcnx,$s);
$req=mysqli_fetch_array($r);
$name='Заявка №'.$req['idorderclient'].'.xls';

	header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename=' . $name);
    header('Content-Transfer-Encoding: binary');
    header('Expires: 0'); 
    header('Cache-Control: must-revalidate');
    header('Pragma: public');   


 	?>				   
		
<html >
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title><? echo $permission;?></title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>


<br>

<font  size="+1" >   Сведения о заявке: </font> 

                 
                                       
                    
  <table WIDTH=100% border=1 cellspacing=0 cellpadding=3>


                      <tr>
                      <td><font  >   Заказчик: </font></td>
                      <td width="240"><?  echo $req['usersystem'];?> </td>
                      </tr>      

                      <tr>
                      <td><font  >   Телефон заказчика: </font></td>
                      <td width="240"><?  echo $req['usersystemphone'];?> </td>
                      </tr>         
	                                                                                             
                       <tr>
                      <td width="172"><font  >   Почта заказчика: </font> </td>
                      <td width="240"><?  echo $req['mail'];?> </td>
                    </tr>  
                    <tr>
                      <td width="172"><font  >   Услуга: </font> </td>
                      <td width="240"><?  echo $req['service'];?> </td>
                    </tr>  
                    <tr>
                      <td width="172"><font  >   Исполнитель: </font> </td>
                      <td width="240"><?  echo $req['executor'];?> </td>
                    </tr>  
           
                      <tr>
                      <td><font  >   Телефон исполнителя: </font></td>
                      <td width="240"><?  echo $req['executorphone'];?> </td>
                      </tr>   
                      <tr>
                      <td><font  >   Дата заявки: </font></td>
                      <td width="240"><?  echo $req['dateorder'];?> </td>
                      </tr> 

                      <tr>
                      <td><font  >   Сроки заявки: </font></td>
                      <td width="240"><?  echo $req['term'];?> </td>
                      </tr> 

                      
                      
                      <tr>
                      <td><font  >   Проблема: </font></td>
                      <td width="240"><?  echo $req['problem'];?> </td>
                      </tr> 

                   
                    <tr>
                      <td width="172"><font  >   Статус: </font> </td>
                      <td width="240"><? echo $req['status'];  ?></td>
                    </tr>  	  

                    <tr>
                      <td width="172"><font  >   Стоимость: </font> </td>
                      <td width="240"><? echo $req['cost'];  ?></td>
                    </tr>          
                               
                                                                       
                  </table>

		

       

</body>
</html>
