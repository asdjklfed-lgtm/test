<?
require "option.php";//файл с параметрами подключения к БД



$step=$_REQUEST["step"];

if ($step==1)
{
$login=$_POST["login"];
$parol=$_POST["parol"];

//авторизация пользователя (проверка наличие пользователя с введенными данными авторизации в базе данных)
//выполнение запроса на выборку данных
$SET_USER=mysqli_query($dbcnx,"select * from usersystem where login='$login' and parol='$parol'");
$COUNT_USER=mysqli_num_rows($SET_USER);





if ($COUNT_USER>0)
{//пользователь есть

		$f=mysqli_fetch_array($SET_USER);//считывание текующей записи
		//заполнение cookie
		$idusersystem=$f["idusersystem"];
		setcookie ( 'idusersystem', $idusersystem); 
		$permission=$f["permission"];	
		setcookie ( 'permission', $permission); 
		$usersystem=$f["usersystem"];
		setcookie ( 'usersystem', $usersystem); 
		$mail=$f["mail"];
		setcookie ( 'mail', $mail); 		


//переход в зависимости от прав доступа
if ($permission=="Администратор")
 {
?>
<script language="javascript">
location.href='usersystem.php?step=0';
</script>
<?	 
 }

if ($permission=="Заказчик")
 {
?>
<script language="javascript">
location.href='reqclt.php?step=0';
</script>
<?	 
 }
 
if ($permission=="Менеджер")
 {
?>
<script language="javascript">
location.href='reqmng.php?step=0';
</script>
<?	 
 } 
}

}


if ($step==2)
{
//выход из системы

//очищение значений в cookie
		$idusersystem='';
		setcookie ( 'idusersystem', $idusersystem); 
		$permission='';	
		setcookie ( 'permission', $permission); 
		$usersystem='';
		setcookie ( 'usersystem', $usersystem); 
		$mail='';
		setcookie ( 'mail', $mail); 
}



?>
<!DOCTYPE html>
<html lang="en">
  <head>
		<title>Услуги маркетинга и рекламы</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
		<link rel='stylesheet' id='camera-css'  href='css/camera.css' type='text/css' media='all'>

		<link rel="stylesheet" type="text/css" href="css/slicknav.css">
		<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" title="prettyPhoto main stylesheet" charset="utf-8" />
		<link rel="stylesheet" type="text/css" href="css/style.css">
		

		<script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>

		<link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700|Open+Sans:700' rel='stylesheet' type='text/css'>
		<script type="text/javascript" src="js/jquery.Праздник.customized.min.js"></script>
		<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
		<script type="text/javascript" src="js/camera.min.js"></script>
		<script type="text/javascript" src="js/myscript.js"></script>
		<script src="js/sorting.js" type="text/javascript"></script>
		<script src="js/jquery.isotope.js" type="text/javascript"></script>
		<!--script type="text/javascript" src="js/jquery.nav.js"></script-->
		

		<script>
			jQuery(function(){
					jQuery('#camera_wrap_1').camera({
					transPeriod: 500,
					time: 3000,
					height: '490px',
					thumbnails: false,
					pagination: true,
					playPause: false,
					loader: false,
					navigation: false,
					hover: false
				});
			});
		</script>
		
	</head>
	<body>
    
<?  
if ( ($step==1) && ($COUNT_USER==0))
{
//ошибка авторизации
?>
<script language="javascript">
alert("Не верный ввод!");
location.href='index.php#auth';
</script>
<?
} 
?>
    
    <!--home start-->
    
    <div id="home">
    	<div class="headerLine">
	<div id="menuF" class="default">
		<div class="container">
			<div class="row">
				<div class="logo col-md-4">
					<div>
						<a href="#">
							<img src="images/logo.png">
						</a>
					</div>
				</div>
				<div class="col-md-8">
					<div class="navmenu"style="text-align: center;">
						<ul id="menu">
							<li class="active" ><a href="#home">Главная</a></li>
							<li><a href="#news">Новости</a></li>
							<li><a href="#member">Услуги</a></li> 
							<li ><a href="#contact">Контакты</a></li>
                            <?
                            if ($permission=="Заказчик")
							{
							?>
							<li class="last"><a href="reqclt.php">Личный кабинет</a></li>                              
                            <?
							}
                            if ($permission=="Менеджер")
							{
							?>
							<li class="last"><a href="reqmng.php">Личный кабинет</a></li>                              
                            <?
							}							
                            if ($permission=="Администратор")
							{
							?>
							<li class="last"><a href="usersystem.php">Личный кабинет</a></li>                              
                            <?
							}														
                            if ($permission=="")
							{
							?>       
							<li class="last"><a href="#auth">Личный кабинет</a></li>     
                            <?
							}
							?>                                              
							<!--li><a href="#features">Features</a></li-->
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
		<div class="container">
			<div class="row wrap">
				<div class="col-md-12 gallery"> 
						<div class="camera_wrap camera_white_skin" id="camera_wrap_1">
							<div data-thumb="" data-src="images/slides/blank.gif">
								<div class="img-responsive camera_caption fadeFromBottom">
									<h2>Служба маркетинга и рекламы</h2>
								</div>
							</div>
							<div data-thumb="" data-src="images/slides/blank.gif">
								<div class="img-responsive camera_caption fadeFromBottom">
									<h2>Широкий ассортимент услуг</h2>
								</div>
							</div>
							<div data-thumb="" data-src="images/slides/blank.gif">
								<div class="img-responsive camera_caption fadeFromBottom">
									<h2>Профессиональные специалисты</h2>
								</div>
							</div>
						</div><!-- #camera_wrap_1 -->
				</div>
			</div>
		</div>
	</div>
		
		<div class="container">
			<div class="row">
				<div class="col-md-12 cBusiness">
					<h3>Приветствуем вас, посетители сайта!</h3>
					<h4>
    Рады приветствовать вас на внутреннем портале службы маркетинга и рекламы Университета!

    <p>Наш портал создан для эффективного взаимодействия со структурными подразделениями вуза — деканатами, факультетами и кафедрами. Здесь вы можете:</p>

    <ul>
        <li>ознакомиться с перечнем доступных маркетинговых и рекламных услуг;</li>
        <li>подать заявку на проведение мероприятия;</li>
        <li>отслеживать статус обработки вашей заявки в режиме реального времени;</li>
        <li>получать актуальные новости и анонсы общевузовских событий.</li>
    </ul>

    <p><strong>Вместе мы делаем наш Университет узнаваемым и привлекательным для абитуриентов, партнёров и общества!</strong></p>

</h4>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-12 centPic">
					<img class="img-responsive"  src="images/bizPic.png"/>
				</div>
			</div>
		</div>   
    </div>
    
    
 
    <!--news start-->
    
    <div id="news">
    	

		<div class="line4">		
			<div class="container">
				<div class="row Ama">
					<div class="col-md-12">
					<h3>Наши новости</h3>
					<p>Узнайте о новых акциях и предложениях</p>
					</div>
				</div>
			</div>
		</div>
<?
$r=mysqli_query($dbcnx,"select *, DATE_FORMAT(datenews, ' %d-%m-%Y %H:%i') as dateformat from news order by datenews DESC");


for ($i=0;$i<mysqli_num_rows($r)-2;$i++)//вывод данных в цикле по количеству записей
			  {
				$f=mysqli_fetch_array($r);//считывание текующей записи	
					if (($i%2)==0)
					{
					?>
					<div class="container">
					<div class="row news">
					<div class="col-md-6  text-left">

					<?				
					}		
					else
					{	
					?>

					<div class="col-md-6 text-right">
					<?
					}
					?>

					<img class="img-responsive picsGall" src="images/news/<? echo $f[file];?>"/>
					<h3><a href="#"><? echo $f[news];?></a></h3>
					<ul>
						<li><i class="fa fa-calendar"></i><? echo $f[dateformat];?></li>
						<li><a href="#"><i class="fa fa-folder-open"></i>Администрация</a></li>
						<li><a href="#"><i class="fa fa-comments"></i>17 </a></li>
					</ul>
					<p><? echo $f[info];?></p>
					<hr class="hrNews">


					</div>






				

					<?
					if ($i%2==1)
					{
					?>
					</div>
					</div>		
					<?
					} ?>
			
<?
}
	?>		
	












<?
for ($i=$i;$i<mysqli_num_rows($r);$i++)//вывод данных в цикле по количеству записей
			  {
				$f=mysqli_fetch_array($r);//считывание текующей записи	
					if (($i%2)==0)
					{
					?>
					<div class="container hideObj2" style="display:none;">
					<div class="row news2 news">
					<div class="col-md-6  text-left">

					<?				
					}		
					else
					{	
					?>

					<div class="col-md-6 text-right">
					<?
					}
					?>

					<img class="img-responsive picsGall" src="images/news/<? echo $f[file];?>"/>
					<h3><a href="#"><? echo $f[news];?></a></h3>
					<ul>
						<li><i class="fa fa-calendar"></i><? echo $f[dateformat];?></li>
						<li><a href="#"><i class="fa fa-folder-open"></i>Администрация</a></li>
						<li><a href="#"><i class="fa fa-comments"></i>17 </a></li>
					</ul>
					<p><? echo $f[info];?></p>
					<hr class="hrNews">


					</div>






				

					<?
					if ($i%2==1)
					{
					?>
					</div>
					</div>		
					<?
					} ?>
			
<?
}
	?>			
			



			<div class="container">
			<div class="row cBtn">
				<div class="col-md-12" style="text-align: center; margin-bottom: -90px; z-index: 10;">
					<ul class="mNews">
						<li class="dowbload bhide2"><a href="#"><i class="fa fa-arrow-down"></i>Загрузить еще</a></li>
					</ul>
				</div>
			</div>
		        </div>

   
 </div>
    
  
  
  
 
     <!--member start-->    
    <div id="member">    
 		<div class="line3">
			<div class="container">
				<div id="project1" ></div>
				<div class="row Ama">
					<div class="col-md-12">
					<span name="projects" id="projectss"></span>
					<h3>Услуги компании</h3>
					<p>Перечень наших услуг</p>

					</div>
				</div>
			</div>
		</div>  
        
<div class="container">
   
 <div  class="tab">
  <button class="tablinks1" onclick="openTab1(event, 'all1')">Показать</button>
  <button class="tablinks1" onclick="openTab1(event, '')">Свернуть</button>  
</div>

<div id="all1" class="tabcontent1" align="center">
      <table  border="1" class="table table-head-bg-success" >
											<thead>
												<tr>
                                                    <th scope="col">Шифр</th>                                                     
                                                    <th  scope="col">Услуга</th> 
                                                    <th  scope="col">Стоимость</th>                                                                                                      
                                                    </tr>
											</thead>
											<tbody>
<?
//формирование запроса на выборку данных
$s="SELECT * from service";
$r=mysqli_query($dbcnx,$s);

			for ($i=0;$i<mysqli_num_rows($r);$i++)//вывод данных в цикле по количеству записей
			  {
				$f=mysqli_fetch_array($r);//считывание текующей записи				
				echo "<tr>";
	
				echo "
				<td> $f[code]</td>					
				<td> $f[service]</td>		
				<td> $f[cost]</td>						
										
																
				";							
				
				echo "</tr>";
			  }		 
		?>
											</tbody>
						
                        				</table>
            </div>    

            
		</div>      
                                   
    </div>





















  
   
    <!--contact start-->
    
    <div id="contact">
    	<div class="line5">					
			<div class="container">
				<div class="row Ama">
					<div class="col-md-12">
					<h3>Чем мы можем Вам помочь?</h3>
					<p>Вы можете оставить обращение в службу поддержки после авторизации</p>
					</div>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-md-9 col-xs-12 forma">
					<form method="post">
						<input type="text" class="col-md-6 col-xs-12 name" name='name' placeholder='Имя *'/>
						<input type="text" class="col-md-6 col-xs-12 Email" name='Email' placeholder='Электронная почта *'/>
						<input type="text" class="col-md-12 col-xs-12 Subject" name='Subject'  placeholder='Тема'/>
						<textarea type="text" class="col-md-12 col-xs-12 Message" name='Message' placeholder='Сообщение *'></textarea>
						<div class="cBtn col-xs-12">
							<ul>
                            <input class="send"  style="font-size:16px" type="button" value="Отправить" onclick="this.form.action='index.php?step=3'; this.form.submit();" >                            
                            <input class="clear"  style="font-size:16px" type="button" value="Очистить" onclick="this.form.action='index.php#contact'; this.form.submit();">




							</ul>
						</div>
					</form>
				</div>
				<div class="col-md-3 col-xs-12 cont">
					<ul>
						<li><i class="fa fa-phone"></i> 800 789 50 12,  800 450 6935</li>
						<li><a href="#"><i class="fa fa-envelope"></i>mail@marketing.com</li></a>
						<li><i class="fa fa-skype"></i>marketing</li>
						<li><a href="#"><i class="fa fa-twitter"></i>Twitter</li></a>
						<li><a href="#"><i class="fa fa-facebook-square"></i>Facebook</li></a>
						<li><a href="#"><i class="fa fa-youtube-play"></i>YouTube</li></a>
					</ul>
				</div>
			</div>
		</div>
		
        

        
               <div id="auth">   
        <div class="line7">
			<div class="container">
				<div class="row footer">
					<div class="col-md-12">

						<h3>Личный кабинет</h3>
						<div class="fr">
						<div style="display: inline-block;">
					<form method="post">
						<input type="text"  style="font-size:18px" class="col-md-6 col-xs-12 name" name='login' placeholder='Логин *'/> <br>
						<input  type="password" style="font-size:18px"  class="col-md-6 col-xs-12 name " name='parol' placeholder='Пароль *'/>

<br>
<div align="center">
                            <input   class="send"  style="font-size:18px" type="button" value="Войти" onclick="this.form.action='index.php?step=1'; this.form.submit();" >       
                             <input   class="send"  style="font-size:18px" type="button" value="Регистрация" onclick="this.form.action='reg.php?step=1'; this.form.submit();" >                         
</div>
							
						
					</form>
                    </div>
                        </div>
                        
                        
                        
                        
                        
                        
					</div>

				</div>
			</div>
		</div>
        </div>
        
        
        
        
        
        
        
        
        
        
        
        
		<div class="lineBlack">
			<div class="container">
				<div class="row downLine">
					<div class="col-md-12 text-right">
						<!--input  id="searchPattern" type="search" name="pattern" value="Search the Site" onblur="if(this.value=='') {this.value='Search the Site'; }" onfocus="if(this.value =='Search the Site' ) this.value='';this.style.fontStyle='normal';" style="font-style: normal;"/-->
						<input  id="searchPattern" type="search" placeholder="Search the Site"/><i class="glyphicon glyphicon-search" style="font-size: 13px; color:#a5a5a5;" id="iS"></i>
					</div>
					<div class="col-md-6 text-left copy">
						<p>Все права защищены &copy; <? echo DATE("Y");?></p>
					</div>
					<div class="col-md-6 text-right dm">
						<ul id="downMenu">
							<li class="active" ><a href="#home">Главная</a></li>
							<li><a href="#news">Новости</a></li>
							<li><a href="#member">Услуги</a></li> 
							<li ><a href="#contact">Контакты</a></li>
                            <?
                            if ($permission=="Заказчик")
							{
							?>
							<li class="last"><a href="reqclt.php">Личный кабинет</a></li>                              
                            <?
							}
                            if ($permission=="Менеджер")
							{
							?>
							<li class="last"><a href="reqmng.php">Личный кабинет</a></li>                              
                            <?
							}
                            if ($permission=="Исполнитель")
							{
							?>
							<li class="last"><a href="reqwrk.php">Личный кабинет</a></li>                              
                            <?
							}							
                            if ($permission=="Администратор")
							{
							?>
							<li class="last"><a href="usersystem.php">Личный кабинет</a></li>                              
                            <?
							}														
                            if ($permission=="")
							{
							?>       
							<li class="last"><a href="#auth">Личный кабинет</a></li>     
                            <?
							}
							?> 
                                                                
							<!--li><a href="#features">Features</a></li-->
						</ul>
					</div>
				</div>
			</div>
		</div>
    </div>		
		
		
	<script src="js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script>
			$(document).ready(function(){
			$(".bhide").click(function(){
				$(".hideObj").slideDown();
				$(this).hide(); //.attr()
				return false;
			});
			$(".bhide2").click(function(){
				$(".container.hideObj2").slideDown();
				$(this).hide(); // .attr()
				return false;
			});
				
			$('.heart').mouseover(function(){
					$(this).find('i').removeClass('fa-heart-o').addClass('fa-heart');
				}).mouseout(function(){
					$(this).find('i').removeClass('fa-heart').addClass('fa-heart-o');
				});
				
				function sdf_FTS(_number,_decimal,_separator)
				{
				var decimal=(typeof(_decimal)!='undefined')?_decimal:2;
				var separator=(typeof(_separator)!='undefined')?_separator:'';
				var r=parseFloat(_number)
				var exp10=Math.pow(10,decimal);
				r=Math.round(r*exp10)/exp10;
				rr=Number(r).toFixed(decimal).toString().split('.');
				b=rr[0].replace(/(\d{1,3}(?=(\d{3})+(?:\.\d|\b)))/g,"\$1"+separator);
				r=(rr[1]?b+'.'+rr[1]:b);

				return r;
}
				
			setTimeout(function(){
					$('#counter').text('0');
					$('#counter1').text('0');
					$('#counter2').text('0');
					setInterval(function(){
						
						var curval=parseInt($('#counter').text());
						var curval1=parseInt($('#counter1').text().replace(' ',''));
						var curval2=parseInt($('#counter2').text());
						if(curval<=707){
							$('#counter').text(curval+1);
						}
						if(curval1<=12280){
							$('#counter1').text(sdf_FTS((curval1+20),0,' '));
						}
						if(curval2<=245){
							$('#counter2').text(curval2+1);
						}
					}, 2);
					
				}, 500);
			});
	</script>
	<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('#menu').slicknav();
		
	});
	</script>
	
	<script type="text/javascript">
    $(document).ready(function(){
       
        var $menu = $("#menuF");
            
        $(window).scroll(function(){
            if ( $(this).scrollTop() > 100 && $menu.hasClass("default") ){
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("default")
                           .addClass("fixed transbg")
                           .fadeIn('fast');
                });
            } else if($(this).scrollTop() <= 100 && $menu.hasClass("fixed")) {
                $menu.fadeOut('fast',function(){
                    $(this).removeClass("fixed transbg")
                           .addClass("default")
                           .fadeIn('fast');
                });
            }
        });
	});
    //jQuery
	</script>
	<script>
		/*menu*/
		function calculateScroll() {
			var contentTop      =   [];
			var contentBottom   =   [];
			var winTop      =   $(window).scrollTop();
			var rangeTop    =   200;
			var rangeBottom =   500;
			$('.navmenu').find('a').each(function(){
				contentTop.push( $( $(this).attr('href') ).offset().top );
				contentBottom.push( $( $(this).attr('href') ).offset().top + $( $(this).attr('href') ).height() );
			})
			$.each( contentTop, function(i){
				if ( winTop > contentTop[i] - rangeTop && winTop < contentBottom[i] - rangeBottom ){
					$('.navmenu li')
					.removeClass('active')
					.eq(i).addClass('active');				
				}
			})
		};
		
		$(document).ready(function(){
			calculateScroll();
			$(window).scroll(function(event) {
				calculateScroll();
			});
			$('.navmenu ul li a').click(function() {  
				$('html, body').animate({scrollTop: $(this.hash).offset().top - 80}, 800);
				return false;
			});
		});		
	</script>	
	<script type="text/javascript" charset="utf-8">

		jQuery(document).ready(function(){
			jQuery(".pretty a[rel^='prettyPhoto']").prettyPhoto({animation_speed:'normal',theme:'light_square',slideshow:3000, autoplay_slideshow: true, social_tools: ''});
			
		});
	</script>
	

<script>
function openTab1(evt, tabName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent1");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks1");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

function openTab2(evt, tabName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent2");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks2");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}

function showTab() {

  var tablinks;
  tablinks = document.getElementsByClassName("tablinks1");
  tablinks[0].click();

  tablinks = document.getElementsByClassName("tablinks2");
  tablinks[0].click();

} 

    
</script>	
	
	</body>
	
</html>