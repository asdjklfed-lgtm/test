<?
require "option.php";

$Arr=$_POST['Arr'];
$id=$Arr[0];

mysqli_query($dbcnx,"DELETE FROM news  WHERE idnews=$id");
?>
 <script language="javascript">
 location.href='news.php';
 </script>
