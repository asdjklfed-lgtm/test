<?
require "option.php";//файл с параметрами подключения к БД
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title><? echo $permission;?></title>
	<meta charset="utf-8" content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="assets/css/ready.css">
	<link rel="stylesheet" href="assets/css/demo.css">
</head>
<body>
<?
if ($permission!="Менеджер")
{
?>
<script language="javascript">
alert("Требуется авторизация!");
</script>
<?
exit;
}


$step=$_REQUEST["step"];
if ($step==2)
{
$upd=$_REQUEST["upd"];

$status = $_POST["status"];
$idexecutor =  $_POST["idexecutor"];
$idservice =  $_POST["idservice"];


	
	
if ($upd==1)
  {  
     $id=$_REQUEST["id"];
	 mysqli_query($dbcnx,"Update orderclient set status='$status', idexecutor=$idexecutor , idservice=$idservice  WHERE idorderclient=$id");


  }  

  ?>
	 <script language="javascript">
	 location.href='reqmng.php?filter=0';
	 </script>
	 <?
}


	 $upd=$_REQUEST["upd"];

	 if ($upd==1)
	 {
	 $Arr=$_REQUEST["arrorderclient"];
	 $idorderclient=$Arr[0];
	 $r=mysqli_query($dbcnx,"select * from orderclient where  idorderclient=$idorderclient");
	 $f=mysqli_fetch_array($r);
	 }
     ?>
     
     
	<div class="wrapper">
		<div class="main-header">
			<div class="logo-header">
				<a href="#" class="logo">
					Менеджер
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<button class="topbar-toggler more"><i class="la la-ellipsis-v"></i></button>
			</div>
			<nav class="navbar navbar-header navbar-expand-lg">
				<div class="container-fluid">
					

					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">

						
						<li class="nav-item dropdown">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false"> <span ><? echo $usersystem;?></span></span> </a>
							<ul class="dropdown-menu dropdown-user">
								<li>
									<div class="user-box">
										
										<div class="u-text">
											<h4><? echo $usersystem;?></h4>
											<p class="text-muted"><? echo $permission;?></p>
											
                                        </div>
									</div>
								</li>
									<div class="dropdown-divider"></div>
									
									<a class="dropdown-item" href="index.php?step=2"><i class="fa fa-power-off"></i> Выход</a>
								</ul>
								<!-- /.dropdown-user -->
							</li>
						</ul>
					</div>
				</nav>
			</div>
			<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
					<div class="user">


					</div>
					<ul class="nav">
						<li class="nav-item">
							<a href="index.php">
								<i class="la la-home"></i>
								<p>Главная</p>
						
							</a>
						</li>
						<li class="nav-item">
							<a href="reqmng.php">
								<i class="la la-dashboard"></i>
								<b><p>Заявки</p></b>
								                                  
							</a>
						</li>
                        <li class="nav-item">
							<a href="executor.php">
								<i class="la la-weixin"></i>
								<p>Исполнители</p>

							</a>
						</li>
                        <li class="nav-item">
							<a href="service.php">
								<i class="la la-star-o"></i>
								<p>Услуги</p>

							</a>
						</li> 						                       				                         <li class="nav-item">
							<a href="news.php">
								<i class="la la-paper-plane"></i>
								<p>Новости</p>

							</a>
						</li>  		
					</ul>
				</div>
			</div>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">

                    
                   
				<div class="card">
				
				
				
				
<form name="form2"  method="post"  enctype="multipart/form-data" >

								
									<div class="card-header">
	 								<? 
									if ($upd==0){ 
									?>
										<div class="card-title">Добавление заявки</div>
                                    <?
									}
									else
									{
									?>
										<div class="card-title">Редактирование заявки №<? echo $f["idorderclient"];?></div>
									<?
                                    					}
									?>  
                                         
									</div>
                                    
									<div class="card-body">
				  <table border="0">
 <tr> 
 <td><font color="#000000" >   Услуги: </font></td>
        <td width="305"><select class="form-control" name="idservice"  style="height:22; width:auto" >
  <?

$d=mysqli_query($dbcnx, "select * from service");
for ($i=0;$i<mysqli_num_rows($d);$i++)
  {
    $m=mysqli_fetch_array($d);
	echo "<option value=".$m["idservice"];
	if (($upd==1)&&    ($m["idservice"]==$f["idservice"]))
	 echo " selected=selected";
	echo ">".$m["service"];
	echo "</option>";	 		
  }
	echo "<option value=NULL";
	if ( ($upd==1)&& ($f["idservice"]==NULL))
	 echo " selected=selected";
	echo ">Не выбрана";
	echo "</option>";	  
?>
					  
          </select></td>
                    </tr>    
  <tr> 
 <td><font color="#000000" >   Исполнитель: </font></td>
        <td width="305"><select class="form-control" name="idexecutor"  style="height:22; width:auto" >
  <?

$d=mysqli_query($dbcnx, "select * from executor");
for ($i=0;$i<mysqli_num_rows($d);$i++)
  {
    $m=mysqli_fetch_array($d);
	echo "<option value=".$m["idexecutor"];
	if (($upd==1)&&    ($m["idexecutor"]==$f["idexecutor"]))
	 echo " selected=selected";
	echo ">".$m["executor"];
	echo "</option>";	 		
  }
	echo "<option value=NULL";
	if ( ($upd==1)&& ($f["idexecutor"]==NULL))
	 echo " selected=selected";
	echo ">Не назначен";
	echo "</option>";	  
?>
					  
          </select></td>
                    </tr>                                                                                                                                         

                                 <tr>
                      <td><font color="#000000" >   Статус: </font></td>
                      <td>
                 <select class="form-control" name="status"  style="height:22; width:auto"    >
					<option   value="Открыто"  <?	if (($upd==1)&& ($f['status']=="Открыто")) echo "selected"; ?> > Открыто </option>	   
                    <option  value="В процессе" <?	if (($upd==1)&& ($f['status']=="В процессе")) echo "selected"; ?> >В процессе </option>
                    <option  value="Готово" <?	if (($upd==1)&& ($f['status']=="Готово")) echo "selected"; ?> >Готово </option>                    	         																				
                    <option  value="Отменено" <?	if (($upd==1)&& ($f['status']=="Отменено")) echo "selected"; ?> >Отменено </option>                    	         																				                    
				</select>                    
				      </td> 
                      </tr>   
  
  
              
 
                      
                  </table>
<br>
				<input class="btn btn-success" type="button"  name="button"   onclick="this.form.action='updreqmng.php?step=2&upd=<? echo"$upd";?>&id=<? echo"$Arr[0]";?>'; this.form.submit();"   value="Сохранить" width="500">
				<input class="btn btn-danger" type="button"  name="button"  onClick="javascript:history.back();"  value="Отмена">
                                    
                                    
                                    	
									</div>

      </form>	            
           					</div>
                            

					</div>
				</div>     
                <div>

                                               
                </div>
				<footer class="footer">
					<div class="container-fluid"  >
						<nav class="pull-left">
							<ul class="nav">

							</ul>
						</nav>
						<div class="copyright ml-auto">
						Все права защищены &copy; <? echo DATE("Y");?>
						</div>				
					</div>
				</footer>
			</div>
		</div>
	</div>
</div>

</body>
<script src="assets/js/core/jquery.3.2.1.min.js"></script>
<script src="assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>
<script src="assets/js/core/bootstrap.min.js"></script>
<script src="assets/js/plugin/chartist/chartist.min.js"></script>
<script src="assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="assets/js/ready.min.js"></script>
<script>
	$('#displayNotif').on('click', function(){
		var placementFrom = $('#notify_placement_from option:selected').val();
		var placementAlign = $('#notify_placement_align option:selected').val();
		var state = $('#notify_state option:selected').val();
		var style = $('#notify_style option:selected').val();
		var content = {};

		content.message = 'Turning standard Bootstrap alerts into "notify" like notifications';
		content.title = 'Bootstrap notify';
		if (style == "withicon") {
			content.icon = 'la la-bell';
		} else {
			content.icon = 'none';
		}
		content.url = 'index.html';
		content.target = '_blank';

		$.notify(content,{
			type: state,
			placement: {
				from: placementFrom,
				align: placementAlign
			},
			time: 1000,
		});
	});
</script>
</html>